<div <?php echo e($attributes->merge($getExtraAttributes())); ?>>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH C:\Users\Admin Alami\Desktop\website project\comppro\vendor\filament\forms\src\/../resources/views/components/grid.blade.php ENDPATH**/ ?>